# Projects

## Sales Performance Dashboard
Tools: Power BI, Excel

## Student Management & Reporting System
Tools: SQL, Excel

## Data Analysis Project
Tools: Python, Pandas, Matplotlib

Replace the sample descriptions with links to your actual project repositories as you complete them.
