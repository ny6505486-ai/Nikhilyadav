# Certifications

Add your real certifications here.

Recommended format:

- Certification Name — Issuing Organization — Year
  - Certificate: https://your-certificate-link

Do not list a certificate unless you have actually earned it.
